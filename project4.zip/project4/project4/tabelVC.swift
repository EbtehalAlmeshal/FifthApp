//
//  tabelVC.swift
//  project4
//
//  Created by Ebtehal 🕸 on 12/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import Foundation
import UIKit

class tabelVC : UIViewController , UITableViewDataSource, UITableViewDelegate{
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var addlocation: UIBarButtonItem!
    @IBOutlet weak var refresh: UINavigationItem!
    @IBOutlet weak var logout: UIBarButtonItem!
    @IBOutlet weak var tabelView: UITableView!
    
    var InformationStudents: [InformationStudents]! {
        print("test1")
        print(Global.shared.InformationStudents.count)
        return Global.shared.InformationStudents
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if (InformationStudents == nil) {
        self.reloadInputViews()
        } else {
            DispatchQueue.main.async {
            self.tabelView.reloadData()
            }
        }
    }
    let cell = "cell"
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tabelView.delegate = self
        tabelView.dataSource = self
    
    }
    
    
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: self.cell, for: indexPath)
        cell.imageView?.image = UIImage(named: "pin")
        cell.textLabel?.text = InformationStudents[indexPath.row].firstName
        cell.detailTextLabel?.text = InformationStudents[indexPath.row].mediaURL
        return cell
    }
    
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let studentLocation = InformationStudents[indexPath.row]
        guard let to0pen = studentLocation.mediaURL , let url = URL(string: to0pen) else { return }
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return InformationStudents?.count ?? 0
        
    }
    
    @IBAction func addLocation(_ sender: Any) {
        if UserDefaults.standard.value(forKey: "studentLocation") != nil {
            let alert = UIAlertController(title: "You have already posted a student location. Would you like to overwrite your current location?", message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
            alert.addAction(UIAlertAction(title: "Overwrite", style: .destructive, handler: { (action) in
                self.performSegue(withIdentifier: "tabelsegue", sender: self)
            }))
            present(alert, animated: true, completion: nil)
        } else {
            self.performSegue(withIdentifier: "tabelsegue", sender: self)
        }
        
    }
    @IBAction func logoutAction(_ sender: Any) {
        UdacityInfo.deleteSession { (error) in
            if let error = error {
            self.alert(title: "Error", message: error.localizedDescription)
                return
            }
            DispatchQueue.main.async {
                self.dismiss(animated: true, completion: nil)
            }
        }
    }
    @IBAction func refreshButton(_ sender: Any) {
        UdacityInfo.Parse.getStudentsLocations { (_, error) in
            if let error = error {
                self.alert(title: "Error", message: error.localizedDescription)
                return
            }
            DispatchQueue.main.async {
            self.tabelView.reloadData()
            }
        }
    }
}
