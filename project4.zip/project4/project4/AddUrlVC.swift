//
//  AddUrlVC.swift
//  project4
//
//  Created by Ebtehal 🕸 on 13/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation
import MapKit

class AddUrlVC :UIViewController  {
    var locationCoordinate: CLLocationCoordinate2D!
    var locationName: String!
    @IBOutlet weak var urlTextField: UITextField!
    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var submitButtom: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = locationCoordinate!
        map.addAnnotation(annotation)
        
        let viewRegion = MKCoordinateRegion(center: locationCoordinate!, latitudinalMeters: 200, longitudinalMeters: 200)
        map.setRegion(viewRegion, animated: false)
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pinId"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        
        return pinView
    }
    
    @IBAction func SubmitAction(_ sender: Any) {
        UdacityInfo.Parse.postStudentLocation(link: urlTextField.text ?? "", locationCoordinate: locationCoordinate, locationName: locationName) { (error) in
            if let error = error {
                self.alert(title: "Error", message: error.localizedDescription)
                return
            }
            UserDefaults.standard.set(self.locationName, forKey: "studentLocation")
            DispatchQueue.main.async {
                self.parent!.dismiss(animated: true, completion: nil)
            }
            
        }
    
    }

 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
