//
//  MapVC.swift
//  project4
//
//  Created by Ebtehal 🕸 on 12/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import Foundation
import MapKit


class MapVC : UIViewController, MKMapViewDelegate {
    var InformationStudents: [InformationStudents]! {
        return Global.shared.InformationStudents
    }
  
    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var refresh: UIBarButtonItem!
    @IBOutlet weak var addlocation: UIBarButtonItem!
    @IBOutlet weak var logout: UIBarButtonItem!
    
    override func viewWillAppear(_ animated: Bool) {
        map.delegate = self
        super.viewWillAppear(animated)
        if (InformationStudents == nil) {
           reloadInputViews()
        } else {
            DispatchQueue.main.async {
                self.updateAnnotations()
            }
        }
        self.refreshButton((Any).self)
    }
    
    @IBAction func refreshButton(_ sender: Any) {
        UdacityInfo.Parse.getStudentsLocations { (_, error) in
            if let error = error {
                self.alert(title: "Error", message: error.localizedDescription)
                return
            }
            DispatchQueue.main.async {
                self.updateAnnotations()
            }
        }
    }
    
    
    @IBAction func addLocation(_ sender: Any) {

        if UserDefaults.standard.value(forKey: "studentLocation") != nil {
            let alert = UIAlertController(title: "You have already posted a student location. Would you like to overwrite your current location?", message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
            alert.addAction(UIAlertAction(title: "Overwrite", style: .destructive, handler: { (action) in
                self.performSegue(withIdentifier: "mapsegue", sender: self)
            }))
            present(alert, animated: true, completion: nil)
        } else {
            self.performSegue(withIdentifier: "mapsegue", sender: self)
        }
        updateAnnotations()
    
    }
    
    @IBAction func logoutAction(_ sender: Any) {
        UdacityInfo.deleteSession { (error) in
            if let error = error {
                self.alert(title: "Error", message: error.localizedDescription)
                return
            }
            DispatchQueue.main.async {
                self.dismiss(animated: true, completion: nil)
            }
        }
    }
    
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            
            let reuseId = "pinId"
            var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
            
            if pinView == nil {
                pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
                pinView!.canShowCallout = true
                pinView!.pinTintColor = .red
                pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            }
            else {
                pinView!.annotation = annotation
            }
            
            return pinView
        }
        
        func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
            if control == view.rightCalloutAccessoryView {
                let app = UIApplication.shared
                guard let toOpen = view.annotation?.subtitle!, let url = URL(string: toOpen) else { return }
                app.open(url, options: [:], completionHandler: nil)
            }
        }
    
    func updateAnnotations() {
        var annotations = [MKPointAnnotation]()
        for studentLocation in InformationStudents {
            
            let lat = CLLocationDegrees(studentLocation.latitude )
            let long = CLLocationDegrees(studentLocation.longitude)
            let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
            
            let first = studentLocation.firstName
            let last = studentLocation.lastName
            let mediaURL = studentLocation.mediaURL
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = "\(first ?? "ebtehal") \(last ?? "aziz")"
            annotation.subtitle = mediaURL
            annotations.append(annotation)
            self.map.addAnnotations(annotations)
//            if !map.annotations.contains(where: {$0.title == annotation.title}) {
//                annotations.append(annotation)
//            }
        //}
        
        print("New annotations = ", annotations.count)
        map.addAnnotations(annotations)
    }

    
}
}


