//
//  Global.swift
//  project4
//
//  Created by Ebtehal 🕸 on 13/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import Foundation


class Global {
    
    static let shared = Global()
    
    var InformationStudents: [InformationStudents] = []
    
    
}



