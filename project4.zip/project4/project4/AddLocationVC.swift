//
//  AddLocationVC.swift
//  project4
//
//  Created by Ebtehal 🕸 on 13/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation
class  AddLocationVC: UIViewController {
    var locationCoordinate: CLLocationCoordinate2D!
    var locationName: String!
    @IBOutlet weak var topLocation: UILabel!
    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var findButtom: UIButton!
    @IBOutlet weak var cancelButtom: UIBarButtonItem!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    func dismissView() {
        dismiss(animated: true, completion: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ToMapSegue" {
            let vc = segue.destination as! AddUrlVC
            vc.locationCoordinate = locationCoordinate
            vc.locationName = locationName
        }
    }
    func update(start: Bool) {
        DispatchQueue.main.async {
            self.activityIndicator.isHidden = !start
            self.findButtom.isEnabled = !start
        }
    }
    
    @IBAction func cancelAction (_sender : Any){
         dismissView()
    }
    @IBAction func findButton(_ sender: UIButton) {
        update(start: true)
        guard let locationName = locationTextField.text?.trimmingCharacters(in: .whitespaces), !locationName.isEmpty
            else {
                alert(title: "Waring", message: "Location should not be empty!")
               update(start: false)
                return
        }
        getCoordinateFrom(location: locationName) { (locationCoordinate, error) in
            if let error = error {
                self.alert(title: "Error", message: "Try different city name.")
                print(error.localizedDescription)
                self.update(start: false)
                
                return
            }
            self.locationCoordinate = locationCoordinate
            self.locationName = locationName
            self.update(start: false)
            self.performSegue(withIdentifier: "ToMapSegue", sender: self)
        }
    }
    
    func getCoordinateFrom(location: String, completion: @escaping(_ coordinate: CLLocationCoordinate2D?, _ error: Error?) -> () ) {
        CLGeocoder().geocodeAddressString(location) { placemarks, error in
            completion(placemarks?.first?.location?.coordinate, error)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
    }
    
    
    
    
    
    
    
    
}
