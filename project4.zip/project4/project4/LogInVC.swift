//
//  LogInVC.swift
//  project4
//
//  Created by Ebtehal 🕸 on 11/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import UIKit
import Foundation

class LogInVC: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    func update(start: Bool) {
        DispatchQueue.main.async {
        self.emailTextField.isUserInteractionEnabled = !start
        self.passwordTextField.isUserInteractionEnabled = !start
        self.loginButton.isEnabled = !start
        
        }
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        activityIndicator.isHidden = true
        emailTextField.text = ""
        passwordTextField.text = ""
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }

    func loginStartActiv(start : Bool) {
        emailTextField.isUserInteractionEnabled = start
        passwordTextField.isUserInteractionEnabled = start
        activityIndicator.isHidden = start
        if start {
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
        }
        }
    @IBAction func loginAction(_ sender: Any) {
        loginStartActiv(start: true)
        guard let email = emailTextField.text?.trimmingCharacters(in: .whitespaces),
        let password = passwordTextField.text?.trimmingCharacters(in: .whitespaces),
            !email.isEmpty, !password.isEmpty
            else {
                alert(title: "Waring", message: "enter your email")
                update(start: false)
                return
        }
        
        UdacityInfo.postSession(with: email, password: password) { (errString) in

            guard errString == nil else {
                self.alert(title: "Error", message: errString!)
                return
            }
                    self.update(start: false)
                    DispatchQueue.main.async {
                        self.emailTextField.text = ""
                        self.passwordTextField.text = ""
                        self.performSegue(withIdentifier: "tapsegue", sender: self)
                    }
                }
                self.update(start: true)
            }
}
//            if let error = error {
//                self.alert(title: "Error", message: error.localizedDescription)
//                self.update(start: false)
//                return
//            }
//            if let error = result?["error"] as? String {
//                self.alert(title: "Error", message: error)
//                self.update(start: false)
//                return
//            }
//            if let session = result?["session"] as? [String:Any], let sessionId = session["id"] as? String {
//                UdacityInfo.deleteSession { (error) in
//                    if let error = error {
//                        self.alert(title: "Error", message: error.localizedDescription)
//                        self.update(start: false)
//                        return
